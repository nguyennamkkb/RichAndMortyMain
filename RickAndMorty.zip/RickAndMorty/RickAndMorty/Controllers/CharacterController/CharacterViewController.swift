//
//  CharacterViewController.swift
//  RickAndMorty
//
//  Created by namnl on 29/03/2023.
//

import UIKit
import ObjectMapper
class CharacterViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var listCharacter = [RMCharacter]()
    var titleController: String?
    @IBOutlet var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        let nib = UINib(nibName: "CharacterCollectionViewCell", bundle: .main)
        collectionView.register(nib, forCellWithReuseIdentifier: "cell")
        // Do any additional setup after loading the view.
        setLayout()
        getCharacters()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listCharacter.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as? CharacterCollectionViewCell else {return UICollectionViewCell()}
        let item = listCharacter[indexPath.row]
        cell.layer.cornerRadius = 5.0
        cell.layer.masksToBounds = true
        cell.layer.borderWidth = 0.1
        
        cell.backgroundView?.layer.shadowColor = UIColor.black.cgColor
        cell.backgroundView?.layer.shadowRadius = 5
        cell.backgroundView?.layer.shadowOpacity = 1
        cell.backgroundView?.layer.shadowOffset = CGSize(width: 2, height: 2)
        
        
        cell.nameCharacter.text = item.name
        cell.statusCharacter.text = "Status: \(item.status ?? "unknown")"
        cell.imageCharacter.loadFromUrl(URLAddress: item.image ?? "")
        
        cell.data = item
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(listCharacter[indexPath.row].toJSON())
    }
    func setLayout(){
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        let width = Constants.screenWidth / 2 - 7.5
        let height = 300
        layout.minimumInteritemSpacing = 2.5
        layout.minimumLineSpacing = 5
        layout.itemSize.width = width
        layout.itemSize.height = CGFloat(height)
        
        collectionView.setCollectionViewLayout(layout, animated: true)
    }
    func getCharacters(){
        
        ServiceManager.common.getCharacters(param: nil){
            (response) in
            if response?.results != nil {
                guard let character =  Mapper<RMCharacter>().mapArray(JSONObject: response?.results) else {return}
                self.listCharacter = character
                
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                }
                
            } else {return}
        }
        
        print("get Character")
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
