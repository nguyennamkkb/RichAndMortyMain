//
//  Constants.swift
//  RickAndMorty
//
//  Created by namnl on 29/03/2023.
//

import UIKit

class Constants {
    static let screenWidth: CGFloat = UIScreen.main.bounds.width
    static let screenHeight: CGFloat = UIScreen.main.bounds.height
    
    
}
