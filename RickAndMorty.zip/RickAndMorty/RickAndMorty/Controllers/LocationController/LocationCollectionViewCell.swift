//
//  LocationCollectionViewCell.swift
//  RickAndMorty
//
//  Created by namnl on 01/04/2023.
//

import UIKit

class LocationCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
